package com.exemplo.projeto.repository;

import com.exemplo.projeto.model.Produto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ProdutoRepository {

    // Utilizando lista em memoria conforme exigido no PDF
    private List<Produto> produtos = new ArrayList<>();
    private Long proximoId = 1L;

    public ProdutoRepository() {
        // Produtos iniciais para que o teste via GET no navegador ja retorne dados
        salvar(new Produto(null, "Notebook", 3500.00));
        salvar(new Produto(null, "Teclado", 150.00));
    }

    public List<Produto> listarTodos() {
        return produtos;
    }

    public Optional<Produto> buscarPorId(Long id) {
        return produtos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    public Produto salvar(Produto produto) {
        if (produto.getId() == null) {
            produto.setId(proximoId++);
        }
        produtos.add(produto);
        return produto;
    }
}
