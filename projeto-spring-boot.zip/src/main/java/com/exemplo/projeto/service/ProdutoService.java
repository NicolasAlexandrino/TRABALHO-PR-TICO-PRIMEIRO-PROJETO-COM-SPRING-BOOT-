package com.exemplo.projeto.service;

import com.exemplo.projeto.model.Produto;
import com.exemplo.projeto.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;

    public ProdutoService(ProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    public List<Produto> listarProdutos() {
        return produtoRepository.listarTodos();
    }

    public Produto buscarPorId(Long id) {
        return produtoRepository.buscarPorId(id).orElse(null);
    }

    public Produto salvarProduto(Produto produto) {
        return produtoRepository.salvar(produto);
    }
}
