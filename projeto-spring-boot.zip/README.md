# API de Cadastro de Produtos

## Descrição
Este é o primeiro projeto prático desenvolvido com Spring Boot. Trata-se de uma API REST simples para gerenciamento (cadastro e consulta) de produtos, desenvolvida para fixar conceitos de organização de um projeto Back-End (Model, Repository, Service e Controller). 

O projeto não utiliza banco de dados externo, armazenando os dados em uma lista em memória, conforme os requisitos da Opção A do trabalho prático.

## Tecnologias utilizadas
* Java 17
* Spring Boot
* Maven

## Como executar no VS Code
1. Certifique-se de ter o **Java Development Kit (JDK 17+)** e o **Extension Pack for Java** instalados no VS Code.
2. Extraia o projeto e abra a pasta raiz no VS Code.
3. Aguarde o Maven baixar as dependências (pode demorar alguns segundos).
4. Localize o arquivo `ProjetoApplication.java` em `src/main/java/com/exemplo/projeto`.
5. Clique em **Run** (acima do método main) ou use a aba *Spring Boot Dashboard* para iniciar a aplicação.
6. A API estará rodando em `http://localhost:8080`.

## Endpoints

* **Consultar Produtos (Navegador)**
  * `GET /produtos`
  * Exemplo de teste no navegador: Acesse `http://localhost:8080/produtos` para ver a lista de produtos cadastrados.

* **Cadastrar Produto**
  * `POST /produtos`
  * Corpo da requisição (JSON):
    ```json
    {
      "nome": "Mouse Gamer",
      "preco": 150.00
    }
    ```
  * *Dica:* Para testar o POST dentro do VS Code, você pode instalar a extensão **Thunder Client**, que funciona de forma semelhante ao Postman/Insomnia.
